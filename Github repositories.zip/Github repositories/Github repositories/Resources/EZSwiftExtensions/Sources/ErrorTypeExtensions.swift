//
//  ErrorTypeExtensions.swift
//  EZSwiftExtensions
//
//  Created by Goktug Yilmaz on 3/23/16.
//  Copyright © 2016 Goktug Yilmaz. All rights reserved.
//

extension Error {

}
