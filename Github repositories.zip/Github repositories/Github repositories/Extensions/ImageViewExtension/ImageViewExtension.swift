//
//  ImageViewExtension.swift
//  Yahuda
//
//  Created by Hira Saleem on 25/06/2021.
//

import Foundation
import Kingfisher
import UIKit
extension UIImageView {
 func setImages(url:String){
    let activityInd = UIActivityIndicatorView()
    activityInd.center = CGPoint(x: self.frame.size.width  / 2,
                                 y: self.frame.size.height / 2)
    activityInd.color = UIColor.gray
    self.addSubview(activityInd)
    activityInd.startAnimating()

        if let urlStr = URL.init(string:url)
        {
            let resource = ImageResource(downloadURL: urlStr)
            let resizingProcessor = ResizingImageProcessor(referenceSize: CGSize(width: self.frame.size.width * UIScreen.main.scale, height: self.frame.size.height * UIScreen.main.scale))
            
            KingfisherManager.shared.retrieveImage(with: resource, options:  [.forceRefresh], progressBlock: nil) { result in
                activityInd.stopAnimating()

                switch result {
                case .success(let value):
                    

                    self.image =  value.image
                    print("Image: \(value.image). Got from: \(value.cacheType)")
                    activityInd.stopAnimating()

                    
                case .failure(let error):
                    activityInd.stopAnimating()

                    print(urlStr)
                    print("Error: \(error)")
                }
            }
        }

    }
    func setImagesNotRefresh(url:String){
       let activityInd = UIActivityIndicatorView()
       activityInd.center = CGPoint(x: self.frame.size.width  / 2,
                                    y: self.frame.size.height / 2)
       activityInd.color = UIColor.red
       self.addSubview(activityInd)
//       activityInd.startAnimating()
        let resizingProcessor = ResizingImageProcessor(referenceSize: CGSize(width: self.frame.size.width * UIScreen.main.scale, height: self.frame.size.height * UIScreen.main.scale))
           if let urlStr = URL.init(string:url)
           {
               let resource = ImageResource(downloadURL: urlStr)

               KingfisherManager.shared.retrieveImage(with: resource, options:  nil, progressBlock: nil) { result in
                activityInd.stopAnimating()

                   switch result {
                   case .success(let value):
                       activityInd.stopAnimating()

                       self.image =  value.image
                       print("Image: \(value.image). Got from: \(value.cacheType)")
                       
                   case .failure(let error):
                       activityInd.stopAnimating()

                       print(urlStr)
                       print("Error: \(error)")
                   }
               }
           }

       }
       
    func imageToUrlResult(image : UIImageView, url: String) -> Bool  {
        image.kf.indicatorType = .activity
        var isResult =  false
        
        if let urlStr = URL.init(string:url)
        {
            //            image.kf.setImage(with: urlStr)
            let resource = ImageResource(downloadURL: urlStr)
            
            KingfisherManager.shared.retrieveImage(with: resource, options:   [.forceRefresh], progressBlock: nil) { result in
                switch result {
                case .success(let value):
                    isResult =  true
                    image.image =  value.image
                    print("Image: \(value.image). Got from: \(value.cacheType)")
                    
                    
                case .failure(let error):
                    isResult = false
                    print(urlStr)
                    print("Error: \(error)")
                }
                
            }
            
            return  isResult
            
            
            //
        }
        return  isResult
        
    }
    func resizeImage(image: UIImage, newWidth: CGFloat) -> UIImage {

        let scale = newWidth / image.size.width
        let newHeight = image.size.height * scale
        UIGraphicsBeginImageContext(CGSize(width: newWidth, height: newHeight))
        image.draw(in: CGRect(x: 0, y: 0, width: newWidth, height: newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage!
    }
}

