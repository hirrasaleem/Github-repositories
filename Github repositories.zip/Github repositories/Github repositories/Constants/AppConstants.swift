//
//  AppConstants.swift
//  Github repositories
//
//  Created by Hira Saleem on 04/10/2021.
//

import Foundation

struct ApplicationIdentifierConstants {
    static let kTableViewCell = "TableViewCell"
}
struct AppNetworkEndPoints {
    static let urlGitHub = "https://api.github.com/search/repositories?q=language=+sort:stars"
}
