//
//  ControllerOperation.swift
//  Github repositories
//
//  Created by Hira Saleem on 04/10/2021.
//

import UIKit
extension ViewController {
    
    func handleDidFinishedWithError(error: Error!) {
        DispatchQueue.main.async {
            self.isShimmer =  false
            self.tableView.reloadData()


        }
    }
    
    func handleDidFinishedWithResponse(response: AnyObject!) {
        let decoder = JSONDecoder()
        
        do {
            let json = response as! [String: Any]
            
            let detailDataJson : Data = try JSONSerialization.data(withJSONObject: json, options: [])
            let passObject = try decoder.decode(GitInfo.self, from: detailDataJson)
            self.arrayItems =  passObject.items ?? []
            DispatchQueue.main.async {
                self.errorView.isHidden = true
                self.isShimmer =  false
                self.tableView.reloadData()
                self.refreshControl.endRefreshing()


            }
        }catch let error {
            print(error.localizedDescription)
            self.refreshControl.endRefreshing()

        }
    }
    
    
    
    //MARK: Request
    func startFetchingOperation() {
        self.isShimmer =  true
        self.tableView.reloadData()
        
        let urlString = AppNetworkEndPoints.urlGitHub
        
        let url = URL(string: urlString)!
        let session = URLSession.shared
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        let task = session.dataTask(with: request as URLRequest, completionHandler: {[self] data, response, error in
            guard error == nil else {
                return
            }
            
            guard let data = data else {
                return
            }
            
            do {
                //create json object from data
                if let json = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String: Any] {
                    print(json)
                    self.handleDidFinishedWithResponse(response: json as AnyObject)
                    
                }
            } catch let error {
                print(error.localizedDescription)
                
            }
            
        })
        task.resume()
    }
    
    
    
}
