//
//  ReachabilityHandler.swift
//  Github repositories
//
//  Created by Hira Saleem on 05/10/2021.
//

import Foundation
import UIKit
extension ViewController{
    func checkReachability()  {

        NotificationCenter.default
                   .addObserver(self,
                                selector: #selector(statusManager),
                                name: .flagsChanged,
                                object: nil)
        
        self.updateUserInterface()
    }
}

