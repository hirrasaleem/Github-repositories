//
//  TableViewCell.swift
//  Github repositories
//
//  Created by Hira Saleem on 04/10/2021.
//

import UIKit
import Shimmer
class TableViewCell: UITableViewCell {
    @IBOutlet weak var shimmerView: FBShimmeringView!

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var userImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var repoName: UILabel!
    @IBOutlet weak var repoLink: UILabel!
    
    @IBOutlet weak var stackView: UIStackView!
    
    @IBOutlet weak var ratingMainView: UIView!
    
    @IBOutlet weak var languageMainView: UIView!
    // MARK: IBOutlet Language
    @IBOutlet weak var languageNameLabel: UILabel!
    
    @IBOutlet weak var languageView: UIView!
    // MARK: IBOutlet Rating
    @IBOutlet weak var ratingImage: UIImageView!
    @IBOutlet weak var ratingNameLabel: UILabel!
    var modalItem : GitItems?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.userImage.layer.cornerRadius = self.userImage.frame.h/2
        self.languageView.layer.cornerRadius = self.languageView.frame.h/2
        self.nameLabel.layer.cornerRadius = 5
        self.nameLabel.layer.masksToBounds = true
        self.repoName.layer.cornerRadius = 5
        self.repoName.layer.masksToBounds = true
        self.repoLink.layer.cornerRadius = 5
        self.repoLink.layer.masksToBounds = true
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func shimmerSetup(isLoaded: Bool)  {
        self.shimmerView.isShimmering = isLoaded
        if isLoaded {
        self.stackView.isHidden = true
        let myColor = !isLoaded ? UIColor.clear : UIColor(hexString: "#edeaf0")

        self.shimmerView.contentView = self.mainView
        self.userImage.image =  UIImage(named: "")
        self.userImage.backgroundColor = myColor
        self.nameLabel.backgroundColor = myColor
        self.repoName.backgroundColor = myColor
        self.repoLink.backgroundColor = myColor

            self.nameLabel.text = " "
            self.repoLink.text =  " "
            self.repoName.text =  " "
        }else {

            if let item = modalItem   {
            
            self.stackView.isHidden = false
            let myColor = UIColor.clear
     
            self.userImage.backgroundColor = myColor
            self.nameLabel.backgroundColor = myColor
            self.repoName.backgroundColor = myColor
            self.repoLink.backgroundColor = myColor
            if item.language == ""{
                self.languageMainView.isHidden = true
            }else {
                self.languageMainView.isHidden = false
                self.languageNameLabel.text =  item.language

            }
            if item.full_name  == ""{
                self.repoName.isHidden =  true
            }else {
                self.repoName.isHidden =  false
                self.repoName.text = item.full_name
            }
            if item.owner?.login == ""{
                self.nameLabel.isHidden = true
            }else {
                self.nameLabel.isHidden = false
                self.nameLabel.text =  item.owner?.login

            }
            self.userImage.setImagesNotRefresh(url: item.owner?.avatar_url ?? "")
            if item.url == ""{
                self.repoLink.isHidden = true

            }else {
                self.repoLink.isHidden = false
                self.repoLink.text =  item.url

            }
            if item.score?.toString == ""{
                self.ratingMainView.isHidden = true

            }else {
                self.ratingMainView.isHidden = false
                self.ratingNameLabel.text = item.score?.toString


            }
            }
            
        }
        
    }
    func setup(item: GitItems) {
        
    }
}
