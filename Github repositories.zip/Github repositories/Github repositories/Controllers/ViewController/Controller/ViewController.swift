//
//  ViewController.swift
//  Github repositories
//
//  Created by Hira Saleem on 04/10/2021.
//

import UIKit

class ViewController: BaseViewController {
    var isShimmer =  false
    @IBOutlet weak var retryButton: UIButton!
    @IBOutlet weak var errorImage: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var errorView: UIView!
    var arrayItems =  [GitItems]()
    lazy var refreshControl: UIRefreshControl = {
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action:
                                    #selector(handleRefresh(_:)),
                                 for: UIControl.Event.valueChanged)
        refreshControl.tintColor = .gray
        
        return refreshControl
    }()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func configureView() {
        self.tableView.addSubview(refreshControl)
        self.errorView.isHidden = true
        self.retryButton.layer.borderWidth = 1
        self.retryButton.layer.cornerRadius = 5
        self.retryButton.layer.borderColor = UIColor(hexString: "#B0D1AF")?.cgColor
        let gifImage = UIImage.gifImageWithName("4506-retry-and-user-busy-version-2")
        
        self.errorImage.image = gifImage
        self.checkReachability()
        
    }
    
    override func configureDataSource() {
        self.tableView.delegate =  self
        self.tableView.dataSource = self
        let tvNib = UINib.init(nibName: ApplicationIdentifierConstants.kTableViewCell, bundle: nil)
        self.tableView.register(tvNib, forCellReuseIdentifier: ApplicationIdentifierConstants.kTableViewCell)
    }
    
    @IBAction func didTapRetry(_ sender: UIButton) {
        self.updateUserInterface()
    }
    // MARK: Reachability
    func updateUserInterface() {
        if ReachabilityInternet.isConnectedToNetwork(){
            self.errorView.isHidden = true
            self.startFetchingOperation()
            
        }else{
            switch Network.reachability.status {
            case .unreachable:
                DispatchQueue.main.async {
                    self.errorView.isHidden = false
                    self.refreshControl.endRefreshing()
                }
                
            case .wwan:
                DispatchQueue.main.async {
                    self.errorView.isHidden = false
                    self.refreshControl.endRefreshing()

                    
                }
            case .wifi:
                DispatchQueue.main.async {
                    self.errorView.isHidden = false
                    self.refreshControl.endRefreshing()

                }
                
                
                print("Reachability Summary")
                print("Status:", Network.reachability.status)
                print("HostName:", Network.reachability.hostname ?? "nil")
                print("Reachable:", Network.reachability.isReachable)
                print("Wifi:", Network.reachability.isReachableViaWiFi)
                
            }
        }
        
    }
    @objc func statusManager(_ notification: Notification) {
        self.checkReachability()

    }
    @objc func handleRefresh(_ refreshControl: UIRefreshControl) {
  
        self.checkReachability()
        
    }
}
extension ViewController: UITableViewDelegate{
    
}
extension ViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if isShimmer{
            return 10
        }else{
            return self.arrayItems.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: ApplicationIdentifierConstants.kTableViewCell, for: indexPath) as! TableViewCell
        cell.selectionStyle = .none
        
        if !self.isShimmer && self.arrayItems.count != 0{
            let modal = arrayItems[indexPath.row]
            cell.modalItem = modal
        }
        cell.shimmerSetup(isLoaded: isShimmer)
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
}
